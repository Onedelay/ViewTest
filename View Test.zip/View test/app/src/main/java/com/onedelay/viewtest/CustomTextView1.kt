package com.onedelay.viewtest

class CustomTextView1 {
}